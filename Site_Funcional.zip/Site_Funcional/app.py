# Importações
from flask import Flask, render_template
import pandas as pd
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import Workbook, load_workbook
from io import BytesIO
import mysql.connector
import matplotlib.pyplot as plt
from flask_sqlalchemy import *

# Configurando o Flask e conectando ao Banco de Dados
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:123456@localhost/teste'
db = SQLAlchemy(app)
con = mysql.connector.connect(
  host="localhost",
  user="root",
  password="123456",
  database="teste"
)
cursor = con.cursor()
cursor.execute("select * from adm")
resultados = cursor.fetchall()

@app.route("/user")
def user():
    # Carregando a planilha em um DataFrame
    df = pd.read_excel("C:/Users/natan/Desktop/NJ_Excel/user.xlsx")
    wb = Workbook()

    # Adicionando o DataFrame como uma nova planilha no arquivo Excel
    ws = wb.active
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)

    # Salvando o arquivo Excel em memória
    saving = BytesIO()
    wb.save(saving)

    # Lendo o arquivo Excel em memória e converte em uma lista de listas de valores inteiros
    saving.seek(0) 
    wb2 = load_workbook(filename=saving, read_only=True, data_only=True)
    ws2 = wb2.active
    excel_data = [[cell for cell in row] for row in ws2.iter_rows(values_only=True)]

    # Renderizando o template HTML que exibe o arquivo Excel
    return render_template("user.html", excel_data=excel_data)

@app.route("/admin")
def admin():
    df = pd.read_excel("C:/Users/natan/Desktop/NJ_Excel/admin.xlsx")
    wb = Workbook()
    ws = wb.active
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
    saving = BytesIO()
    wb.save(saving)
    wb2 = load_workbook(filename=saving, read_only=True, data_only=True)
    ws2 = wb2.active
    excel_data = [[cell for cell in row] for row in ws2.iter_rows(values_only=True)]
    return render_template("admin.html", excel_data=excel_data)

@app.route("/grafl")
def grafl():
    cursor.execute("SELECT * FROM graficolinh")
    graf = cursor.fetchall()
    x = [row[0] for row in graf]
    y = [row[1] for row in graf]

    # Criando o gráfico de linha
    fig, ax = plt.subplots()
    ax.plot(x, y)

    # Salvando o gráfico em um arquivo
    fig.savefig('static/grafl.png')

    # Renderizando a página HTML que mostra o gráfico
    return render_template('grafl.html')

@app.route("/grafp")
def grafp():
    cursor.execute("SELECT * FROM graficopi")
    graf = cursor.fetchall()
    labels = [row[0] for row in graf]
    sizes = [row[1] for row in graf]
    plt.figure(figsize=(10,10))
    # Criando o gráfico de pizza
    plt.pie(sizes, labels=labels, autopct='%1.1f%%')
    # Definindo o título do gráfico
    plt.title('Porcentagem dos Administradores')
    # Salvando o gráfico em um arquivo
    plt.savefig('static/grafp.png')
    return render_template("grafp.html")

@app.route("/")
def home():
    cursor.execute("SELECT * FROM graficolinh")
    graf = cursor.fetchall()
    x = [row[0] for row in graf]
    y = [row[1] for row in graf]
    # Criando o gráfico de linha
    fig, ax = plt.subplots()
    ax.plot(x, y)
    # Salvando o gráfico em um arquivo
    fig.savefig('static/grafl.png')
    
    cursor.execute("SELECT * FROM graficopi")
    graf = cursor.fetchall()
    labels = [row[0] for row in graf]
    sizes = [row[1] for row in graf]
    plt.figure(figsize=(10,10))
    # Criando o gráfico de pizza
    plt.pie(sizes, labels=labels, autopct='%1.1f%%')
    # Definindo o título do gráfico
    plt.title('Porcentagem dos Administradores')
    # Salvando o gráfico em um arquivo
    plt.savefig('static/grafp.png')
    # Renderizando a página HTML que mostra o gráfico
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
    
