from flask import *
from flask_sqlalchemy import *


site = Flask(__name__)
site.config['SQLALCHMY DATABASE_URI'] = 'sqlite:///teste.sqlite3'

db = SQLAlchemy(site)


class Compra(db.Model):
    id = db.Column('id', db.Integer, primary_key=True, autoincrement=True)
    produto = db.Column(db.String(150))
    quantidade = db.Column(db.Integer)  
    preco = db.Column(db.Integer)

    def __init__(self, produto, quantidade, preco):
        self.produto = produto
        self.quantidade = quantidade
        self.preco = preco


# criar a page1
# route = URL depois do / >>> natansales.com/route

# funcao > o que vai passar na pagina


@site.route("/")
def homepage():
    compra = Compra.query.all()
    return render_template("homepage.html", compra=compra)


@site.route("/add", methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        compra = Compra(request.form['produto'], request.form['quantidade'], request.form['preco'])
        db.session.add(compra)
        db.session.commit()
        return redirect(url_for('homepage'))
    return render_template('cadastro.html')


@site.route("/delete/<int:id>")
def delete(id):
    compra = Compra.query.get(id)
    db.session.delete(compra)
    db.session.commit()
    return redirect(url_for('homepage'))


@site.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    compra = Compra.query.get(id)
    if request.method == 'POST':
        compra.produto = request.form['produto']
        compra.quantidade = request.form['quantidade']
        compra.preco = request.form['preco']
        db.session.commit()
        return redirect(url_for('homepage'))
    return render_template('edit.html', compra=compra)

# colocar o site no ar


if __name__ == "__main__":
    db.create_all()
    site.run(debug=True)
